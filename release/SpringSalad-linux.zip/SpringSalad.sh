
java -jar -Xms64m -Xmx1024m SpringSalad-linux.jar
     